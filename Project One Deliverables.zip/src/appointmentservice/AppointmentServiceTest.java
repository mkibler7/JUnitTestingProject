package appointmentservice;


import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class AppointmentServiceTest {


	@Test
	void testAddAppointment() {
		AppointmentService service = new AppointmentService();
		Appointment appointment = new Appointment("app1", new Date(128, 4, 6), "Appointment Description.");
		
		service.addAppointment(appointment);
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.addAppointment(appointment);
		});
		
		Appointment retrieved = service.getAppointment("app1");
	
		assertTrue(retrieved.getAppointmentID().equals("app1"));
		assertTrue(retrieved.getDate().equals(new Date(128, 4, 6)));
		assertTrue(retrieved.getDescription().equals("Appointment Description."));
	}
	
	@Test 
	void testAddAppointmentDuplicateID() {
		AppointmentService service = new AppointmentService();
		Appointment appointment1 = new Appointment("app10", new Date(), "Appointment Description");
		
		service.addAppointment(appointment1);
		
		Appointment appointment2 = new Appointment("app10", new Date(), "Appointment Description Duplicate.");
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.addAppointment(appointment2);
		});
	}
	
	@Test 
	void testDeleteAppointment() {
		AppointmentService service = new AppointmentService();
		
		Appointment appointment = new Appointment("app2", new Date(), "Appointment Description");
		
		service.addAppointment(appointment);
		
		service.deleteAppointment("app2");
	
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.deleteAppointment("app2");
		});
	}
	
	

	@Test 
	void testGetAppointment() {
		AppointmentService service = new AppointmentService();
		
		Appointment appointment= new Appointment("app7", new Date(), "Appointment Description");
		
		service.addAppointment(appointment);
		
		Appointment returned = service.getAppointment("app7");
		
		assertTrue(returned.getAppointmentID().equals("app7"));	
		assertTrue(returned.getDate().equals(new Date()));
		assertTrue(returned.getDescription().equals("Appointment Description"));
	}
		
	@Test 
	void testGetTaskIsNull() {
		AppointmentService service = new AppointmentService();
		
		Appointment appointment = new Appointment("app8", new Date(), "Appointment Decription");
		
		service.addAppointment(appointment);
		
		service.deleteAppointment("app8");
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.getAppointment("app8");
		});
	}
}

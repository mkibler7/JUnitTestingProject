package contactservice;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactServiceTest {

	@Test
	void testAddContact() {
		ContactService service = new ContactService();
		Contact contact = new Contact("contact1", "Michael", "Kibler", "(714)123-4567", "9234 Element Ave.");
		
		service.addContact(contact);
		
		Contact retrieved = service.getContact("contact1");
		assertTrue(retrieved.getFirstName().equals("Michael"));
	}
	
	@Test 
	void testAddContactDuplicateID() {
		ContactService service = new ContactService();
		Contact contact1 = new Contact("contact10", "Joe", "Dirt", "(123)456-7890", "1042 Lily Ave.");
		
		service.addContact(contact1);
		
		Contact contact2 = new Contact("contact10", "Paul", "Smith", "(143)456-7890", "1052 Lily Ave.");
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.addContact(contact2);
		});
	}
	
	@Test 
	void testDeleteContact() {
		ContactService service = new ContactService();
		
		Contact contact = new Contact("contact2", "Michael", "Kibler", "(714)123-4567", "9234 Element Ave.");
		
		service.addContact(contact);
		
		service.deleteContact("contact2");
	
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.deleteContact("contact2");
		});
	}
	
	@Test
	void testUpdateFirstName() {
		ContactService service = new ContactService();
		
		Contact contact = new Contact("contact3", "Michael", "Kibler", "(714)123-4567", "9234 Element Ave.");
		
		service.addContact(contact);
		
		service.updateFirstName("contact3", "Paul");
		
		assertTrue(contact.getFirstName().equals("Paul"));
		
	}
	
	@Test
	void testUpdateLastName() {
		ContactService service = new ContactService();
		
		Contact contact = new Contact("contact4", "Michael", "Kibler", "(714)123-4567", "9234 Element Ave.");
		
		service.addContact(contact);
		
		service.updateLastName("contact4", "Roger");
		
		assertTrue(contact.getLastName().equals("Roger"));
		
	}
	
	@Test
	void testUpdatePhone() {
		ContactService service = new ContactService();
		
		Contact contact = new Contact("contact5", "Michael", "Kibler", "(714)123-4567", "9234 Element Ave.");
		
		service.addContact(contact);
		
		service.updatePhone("contact5", "(714)321-4567");
		
		assertTrue(contact.getPhone().equals("(714)321-4567"));
		
	}
	
	@Test
	void testUpdateAddress() {
		ContactService service = new ContactService();
		
		Contact contact = new Contact("contact6", "Michael", "Kibler", "(714)123-4567", "9234 Element Ave.");
		
		service.addContact(contact);
		
		service.updateAddress("contact6", "1234 Helmet St.");
		
		assertTrue(contact.getAddress().equals("1234 Helmet St."));
		
	}
	
	@Test 
	void testGetContact() {
		ContactService service = new ContactService();
		
		Contact contact = new Contact("contact7", "Michael", "Kibler", "(714)123-4567", "9234 Element Ave.");
		
		service.addContact(contact);
		
		Contact returned = service.getContact("contact7");
		
		assertTrue(returned.getFirstName().equals("Michael"));	
		assertTrue(returned.getLastName().equals("Kibler"));
		assertTrue(returned.getPhone().equals("(714)123-4567"));
		assertTrue(returned.getAddress().equals("9234 Element Ave."));
	}
		
	@Test 
	void testGetContactIsNull() {
		ContactService service = new ContactService();
		
		Contact contact = new Contact("contact8", "Michael", "Kibler", "(714)123-4567", "9234 Element Ave.");
		
		service.addContact(contact);
		
		service.deleteContact("contact8");
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.getContact("contact8");
		});
	}
}

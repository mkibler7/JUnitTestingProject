package taskservice;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class TaskServiceTest {


	@Test
	void testAddTask() {
		TaskService service = new TaskService();
		Task task = new Task("task1", "Task Name", "Task Description.");
		
		service.addTask(task);
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.addTask(task);
		});
		
		Task retrieved = service.getTask("task1");
	
		assertTrue(retrieved.getTaskID().equals("task1"));
		assertTrue(retrieved.getName().equals("Task Name"));
		assertTrue(retrieved.getDescription().equals("Task Description."));
	}
	
	@Test 
	void testAddContactDuplicateID() {
		TaskService service = new TaskService();
		Task task1 = new Task("task10", "Task Name", "Task Description");
		
		service.addTask(task1);
		
		Task task2 = new Task("task10", "Task Name Duplicate", "Task Description Duplicate.");
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.addTask(task2);
		});
	}
	
	@Test 
	void testDeleteTask() {
		TaskService service = new TaskService();
		
		Task task = new Task("task2", "Task Name", "Task Description");
		
		service.addTask(task);
		
		service.deleteTask("task2");
	
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.deleteTask("task2");
		});
	}
	
	@Test
	void testUpdateName() {
		TaskService service = new TaskService();
		
		Task task = new Task("task3", "Task Name", "Task Description");
		
		service.addTask(task);
		
		service.updateName("task3", "New Task Name");
		
		assertTrue(task.getName().equals("New Task Name"));
		
	}

	
	@Test
	void testUpdateDescription() {
		TaskService service = new TaskService();
		
		Task task = new Task("task5", "Task Name", "Task Description");
		
		service.addTask(task);
		
		service.updateDescription("task5", "New Task Description");
		
		assertTrue(task.getDescription().equals("New Task Description"));
		
	}

	@Test 
	void testGetTask() {
		TaskService service = new TaskService();
		
		Task task = new Task("task7", "Task Name", "Task Description");
		
		service.addTask(task);
		
		Task returned = service.getTask("task7");
		
		assertTrue(returned.getTaskID().equals("task7"));	
		assertTrue(returned.getName().equals("Task Name"));
		assertTrue(returned.getDescription().equals("Task Description"));
	}
		
	@Test 
	void testGetTaskIsNull() {
		TaskService service = new TaskService();
		
		Task task = new Task("task8", "Task Name", "Task Decription");
		
		service.addTask(task);
		
		service.deleteTask("task8");
		
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.getTask("task8");
		});
	}
}
